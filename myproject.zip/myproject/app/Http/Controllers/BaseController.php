<?php


namespace App\Http\Controllers;


class BaseController
{

}
