@extends('layouts.header2')

@section('content2')
<div class="main">
    <div class="logo">
        <p><a href="index.html">ELECTRONICS</a></p>
    </div>
    <div>
        <form>
            <input type="text" placeholder="Искать здесь...">
            <button type="submit"></button>
        </form>
    </div>
    <div class="top-right">
        <p><a href="login.html" class="login">Log In </a> | <a href="index.html" class="login">MyAccount</a>  <a href="index.html">Help</a> | <a href="index.html">Contacts</a> </p>
    </div>
    <div class="slide">
        <input type="radio" name="slider2" id="slider2_1" checked="checked">
        <label for="slider2_1"></label>
        <div><img src="img/foto1.jpg"></div>
        <label for="slider2_2"></label>
        <input type="radio" name="slider2" id="slider2_2">
        <label for="slider2_2"></label>
        <div><img src="img/foto2.jpg"></div>
        <label for="slider2_3"></label>
        <input type="radio" name="slider2" id="slider2_3">
        <label for="slider2_3"></label>
        <div><img src="img/foto3.jpg"></div>
        <label for="slider2_4"></label>
    </div>
    <div class="icon-bar">
        <a class="active" href="#"><i class="fa fa-mobile-phone"></i></a>
        <a href="#"><i class="fa fa-calculator"></i></a>
        <a href="#"><i class="fa fa-microchip"></i></a>
        <a href="#"><i class="fa fa-laptop"></i></a>
        <a href="korzina.html"><i class="fa fa-trash"></i></a>
    </div>
    <div class="featured_products">
        <ul class="products clearfix">
            <li class="product-wrapper">
                <a href="acer.html" class="product">
                    <div class="product-photo">
                        <img src="img/notebook.jpg" alt="">
                    </div>
                    <div class="products_h1">
                        <h1><center>Купить сейчас</center></h1>
                        <h1><center>31.699 p.</center></h1>
                        <h1><center>Ноутбук Acer</center></h1>
                    </div>
                    <div class="product-price-old">
                        <h2 align="right">самовывоз<i class="fa fa-check"></i></h2>
                        <h2 align="right">доставка<i class="fa fa-check"></i></h2>
                    </div>
                </a>
            </li>
            <li class="product-wrapper">
                <a href="korzina.html" class="product">
                    <div class="product-photo">
                        <img src="img/macbook.jpg" alt="">
                    </div>
                    <div class="products_h1">
                        <h1><center>Купить сейчас</center></h1>
                        <h1><center>102.900 p.</center></h1>
                        <h1><center>Ноутбук Apple</center></h1>
                    </div>
                    <div class="product-price-old">
                        <h2 align="right">самовывоз<i class="fa fa-check"></i></h2>
                        <h2 align="right">доставка<i class="fa fa-check"></i></h2>
                    </div>
                </a>
            </li>
            <li class="product-wrapper">
                <a href="korzina.html" class="product">
                    <div class="product-photo">
                        <img src="img/notebook-msi.jpg" alt="">
                    </div>
                    <div class="products_h1">
                        <h1><center>Купить сейчас</center></h1>
                        <h1><center>48.999 p.</center></h1>
                        <h1><center>Ноутбук MSI</center></h1>
                    </div>
                    <div class="product-price-old">
                        <h2 align="right">самовывоз<i class="fa fa-check"></i></h2>
                        <h2 align="right">доставка<i class="fa fa-check"></i></h2>
                    </div>
                </a>
            </li>
            <li class="product-wrapper">
                <a href="korzina.html" class="product">
                    <div class="product-photo">
                        <img src="img/gpd-win.jpg" alt="">
                    </div>
                    <div class="products_h1">
                        <h1><center>Купить сейчас</center></h1>
                        <h1><center>57.999 p.</center></h1>
                        <h1><center>Ноутбук GPD Win</center></h1>
                    </div>
                    <div class="product-price-old">
                        <h2 align="right">самовывоз<i class="fa fa-check"></i></h2>
                        <h2 align="right">доставка<i class="fa fa-check"></i></h2>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>
@endsection
