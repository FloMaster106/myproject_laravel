<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ноутбук Acer SWIFT 3 SF514-54GT: характеристики и цена</title>
    <link rel="stylesheet" href="css/acer.css">
    <meta charset="utf-8">
    <title>Кнопка</title>


    <style id="fit-vids-style">.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style></head>

</head>
<body>
@yield('content')
</body>
</html>
