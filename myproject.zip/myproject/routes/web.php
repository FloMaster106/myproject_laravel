<?php

use App\Http\Controllers\IndexController;
use App\Http\Controllers\IndexRegController;
use App\Http\Controllers\KorzinaController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [IndexController::class, 'index']);
Route::get('/indexReg', [IndexRegController::class, 'index']);
Route::get('/kor', [KorzinaController::class, 'index']);
Route::get('/log', [LoginController::class, 'index']);
Route::post('/log', [LoginController::class, 'login']);
Route::get('/reg', [RegisterController::class, 'index']);
Route::post('/reg', [RegisterController::class, 'create']);



