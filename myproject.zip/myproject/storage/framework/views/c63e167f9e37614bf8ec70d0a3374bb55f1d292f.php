<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Online-store ELECTRONICS</title>
    <link rel="stylesheet" href="css/style4.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/jscript.js"></script>
</head>
<body>
<?php echo $__env->yieldContent('content4'); ?>
</body>
</html>
<?php /**PATH D:\myproject\resources\views/layouts/header4.blade.php ENDPATH**/ ?>